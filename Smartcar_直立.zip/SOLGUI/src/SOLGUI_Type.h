#ifndef SOLGUI_TYPE_H		
#define SOLGUI_TYPE_H

typedef enum {False=0,True=!False} boolean;

typedef unsigned long  u32;
typedef unsigned short u16;
typedef unsigned char  u8;

typedef signed long  s32;
typedef signed short s16;
typedef signed char  s8;

#endif
