#ifndef FONT4X6_ASCII_H
#define FONT4X6_ASCII_H

#include"SOLGUI_Type.h"

extern const u8 _Font4x6[][6];

#endif







