#ifndef FONT8X8_ASCII_H
#define FONT8X8_ASCII_H

#include"SOLGUI_Type.h"

extern const u8 _Font8x8[][8];

#endif
