#ifndef FONT6X8_ASCII_H
#define FONT6X8_ASCII_H

#include"SOLGUI_Type.h"

extern const u8 _Font6x8[][8];

#endif
