#ifndef FONT8X10_ASCII_H
#define FONT8X10_ASCII_H

#include"SOLGUI_Type.h"

extern const u8 _Font8x10[][10];

#endif
